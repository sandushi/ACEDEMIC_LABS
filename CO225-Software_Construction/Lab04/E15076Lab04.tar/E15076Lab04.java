import java.io.File;
import java.lang.String;
import java.util.Arrays;
import java.util.Scanner;
import java.util.HashMap;
import java.io.File;
import java.util.ArrayList;

/*This Contact class is to put the values from the csv file to an array list*/
class Contact{
	
	/*Declaring the variavles*/
	private String fName;
	private String lName;
	private String telNo;
	
	Contact(String fName,String lName,String telNo){
		this.fName = fName;   /*Initializing the variables with the values passing through the constructor*/
		this.lName=lName;
		this.telNo=telNo;
	}

     
    
    /*getter methods for private varibles*/
    public String getfName() {
        return fName;
    }

    public String getlName() {
        return lName;
    }

    public String getTelNo() {
        return telNo;
    }
	
	
	
}


public class E15076Lab04{

private static Scanner x;

public static void main(String[] args){
	Scanner sc= new Scanner(System.in);
	String filepath="contactsList.csv";   /*Giving the file path*/
	System.out.println(" ");
	int pvalue=0;
	char[] term = sc.next().toCharArray();  
	
	
	/*Checking whether the user input first name or the last name*/
	if(term[0]=='F'){
	pvalue=1;}
	
	if(term[0]=='L'){
	pvalue=2;}
		
	/*Getting only the name ingoring the prefix*/	
	int j=0;
	char[] newterm=new char[term.length-2];
		for(int i=2;i<term.length;i++){
		 newterm[j]=term[i];
		 j++;}
		
    String searchterm= new String(newterm);
	
	/*Creating an array list to put the values form the csv file*/
	ArrayList<Contact> contacts = new ArrayList<Contact>();
	
	try{
	x= new Scanner(new File(filepath));
		x.useDelimiter("[,\n]");  /* Break the words which are seperating by commas*/
	
	/*Putting the values to the array list*/
    do {
        String firstName = x.next();
        String lastName = x.next();
        String interest = x.next();
        contacts.add(new Contact(firstName, lastName, interest));
    } while (x.hasNext());
	
	
	/*Getting the telephone number of the person who searched by the user.The telephone numbers are get into an array because there can be more than one person with the same name*/
    int k=0;
	String []tel=new String[10];
	String []name=new String[10];
	boolean found=false;
	
	
	/*Checking for the inserted name and put the telephone numbers and name into the array*/
	for(Contact c : contacts){
           
		if(pvalue==1){
			if(searchterm.equals(c.getfName())){
				tel[k] = c.getTelNo();
				name[k]=c.getlName();
				k++;
				found=true;
			}
		}
		
		if(pvalue==2){
			if(c.getlName().equals(searchterm)){
				tel[k] = c.getTelNo();
				name[k]=c.getfName();
				k++;
				found=true;
			}
		}
	} 
	
	/*Printing the telephone number*/
	if(found){
		if(k>1){
		for(int p=0;p<k;p++){
			System.out.println(name[p]+":"+tel[p]);}
	
	}
		else{
		System.out.println(tel[0]);}
	}
	else{
	System.out.println("The contact is not found");
	}
	
	
	
	}

catch(Exception e){
	
		}
	}
}
