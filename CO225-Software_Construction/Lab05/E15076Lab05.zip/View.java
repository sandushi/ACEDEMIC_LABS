//package view;


//import adapter.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

import javax.swing.*;

public class View {
	private Adapter adapter;
	private JFrame panel;
  private JButton[][] buttons;


    // default constructor to initialize the gui as JFrame
    public View() {
    		this.panel = new JFrame("Tic Tac Toe Game");
    		this.buttons = new JButton[3][3];
    		initialize();
    }


    public void setActionListener(Controller c) {
			this.adapter = new Adapter(c,this);
			for(int row = 0; row<3 ;row++) {
	        for(int column = 0; column<3 ;column++) {
	        		buttons[row][column].addActionListener(adapter);
	        }
		}

    }

    public void initialize () {
			panel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    panel.setSize(new Dimension(300, 300));
	    panel.setResizable(true);
      //Jpanel for the game
	   	JPanel game = new JPanel(new GridLayout(3,3));
	   	panel.add(game, BorderLayout.CENTER);
	    JPanel options = new JPanel(new FlowLayout());

     //add the buttons to the panel
	    for(int row = 0; row<3 ;row++) {
	        for(int col = 0; col<3 ;col++) {
	            buttons[row][col] = new JButton();
	            buttons[row][col].setPreferredSize(new Dimension(90,90));
	            buttons[row][col].setText("");
	            game.add(buttons[row][col]);

		    }
		}

	    // make the gui visible as the final step
	    panel.setVisible(true);

    }


    // function to find the pressed button
    public ArrayList<Integer> getPosition(ActionEvent e) {
    	ArrayList<Integer> position = new ArrayList<Integer>();
    	for(int row = 0; row<3 ;row++) {
	        for(int column = 0; column<3 ;column++) {
	        		if(e.getSource() == buttons[row][column]) {
	        			position.add(row);
	        			position.add(column);
	        		}
	        }
    		}
    		return position;
    }

    // function to update the view with the correct mark and message
    public void markButtons(int row, int column, char symbol) {
    		buttons[row][column].setText(Character.toString(symbol));
    		buttons[row][column].setEnabled(false);

    }


    // function to clear the view and reset it for a new game
    public void reset() {
    	for(int row = 0;row<3;row++) {
            for(int column = 0;column<3;column++) {
                buttons[row][column].setText("");
                buttons[row][column].setEnabled(true);
            }
        }
    }

    // make getter function for checking the value of a button on the grid
    public String getButtonText(int i, int j) {
    		return buttons[i][j].getText();
    }

}
