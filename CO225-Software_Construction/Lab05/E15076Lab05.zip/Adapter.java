//package adapter;

//import controller.*;
//import view.*;
import java.awt.event.*;
import java.util.*;

public class Adapter implements ActionListener {
	private Controller c;
	private View v;

	// initializing the references of the controller and view classes
    public Adapter(Controller c, View v) {
        this.c = c;
        this.v = v;
    }

    // Implementation of the actionPerformed method for the ActionListener interface
    public void actionPerformed(ActionEvent e) {
    			ArrayList<Integer> position = v.getPosition(e);
    			c.setRequest(position);
    }

}
