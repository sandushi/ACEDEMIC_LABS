//package model;



//import view.*;
import javax.swing.*;

public class Model {
	private View v;
	private int player;
	private int count;
	private char[][] buttons;


	// default constructor
	public Model() {
		this.buttons = new char[3][3];
		this.count = 9;
		this.player = 1;
	}

	// initializing the reference of view class
	public void register(View v) {
		this.v = v;
	}

	//setters and getters
	public int getPlayer() {
		return player;
	}

	public void setPlayer(int player) {
		this.player = player;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public char[][] getBoard() {
		return buttons;
	}

	public void setBoard(char[][] board) {
		this.buttons = buttons;
	}



	// function to update the board model
	public void Play(int x, int y) {

		if(getCount() > 0){
			// mark the board with 1 or 2 when they play
			if(getPlayer()%2 != 0)
				buttons[x][y] = '1';
			else
				buttons[x][y] = '2';

				setCount(--count);
				v.markButtons(x, y, buttons[x][y]);



			if(checkWin(x, y)) {
				//check whether the if palyer 1 is the winner
      	if(player%2!=0){
      		JOptionPane.showMessageDialog(null, "Player 1 is win");
					resetModel();
				}

				//check whether player 2 is the Winner
      	if(player%2==0){
      		JOptionPane.showMessageDialog(null, "Player 2 is win");
					resetModel();
				}
			}


			else if(getCount()==0) {
				//Check the is game raw
  			JOptionPane.showMessageDialog(null, "Game is draw");
				resetModel();
			}

			else {
				if(player%2 != 0) {
					setPlayer(2);
				}

				else {
					setPlayer(1);
				}

			}

		}

	}

	// function to check if there is a winner
	public boolean checkWin(int x, int y) {
		int rowCount = 0;
		int colCount = 0;
		int main_Dia_Count = 0;
		int dia_Count = 0;
		char symbol;


		if(getPlayer() %2 !=0)
			symbol = '1';
		else
			symbol = '2';

		for(int i=0; i<buttons.length;i++) {
			if(buttons[x][i] == symbol)
				rowCount++;
			if(buttons[i][y] == symbol)
				colCount++;
			if(buttons[i][i] == symbol)
				dia_Count++;
			if(buttons[buttons.length-1-i][i] == symbol)
				main_Dia_Count++;
		}


//possibitilies for win
		if(colCount==buttons.length || rowCount==buttons.length
		   || main_Dia_Count == buttons.length || dia_Count == buttons.length)
			return true;

		return false;
	}

	// function to clear the model and reset it to initial state
	public void resetModel() {
		count = 9;
		setPlayer(1);
		for(int i=0; i<buttons.length;i++) {
			for(int j=0; j<buttons.length;j++) {
				buttons[i][j] = '\0';
			}
		}
		v.reset();

	}

}
