import java.util.*;
class Main { 

  public static int [][] a = {{1, 1, 1},
				{1, 1, 1},
				{1, 1, 1}};
    
    public static int [][] b = {{1 },
				{1 },
				{1 }};
    
	/*Method for print the result matrix*/			
public static void print_matrix(int [][] m) {
	for(int i=0; i < m.length; i++) {
	    for(int j=0; j< m[i].length; j++) 
		System.out.print(m[i][j] + " "); 
	    System.out.println();
		}
    }
	
	
public static void main(String [] args) throws Exception { 



	/*If there are large matrices we can rondomly generate matices to check the code
	
	
	 Random r =new Random();         //Random class to create random matrices
	 int p=200;						//Initializing and declaring  the size of the matrices
	 int q=200;
	 int r=200;
	  int boundOfNumbers=20;			//Initialize and declaring the bound number of random
	
	
	 
	 
	 int [][] matrixA = new int[p][q];    //Initializing the three matrices
	 int [][] matrixB = new int[q][r];
	 MatrixThread.c = new int[p][r];
	 
	 
	 //Putting values for matrix A
	 for(int i=0;i<p;i++){                  
		for(int j=0;j<q;j++){
			matrixA[i][j]=r.nextInt(boundOfNumbers);
		}
		}
		
		
		Putting values for matrix B
		 for(int i=0;i<q;i++){      
		for(int j=0;j<r;j++){
			matrixB[i][j]=r.nextInt(boundOfNumbers);
		}
		}
			
			
		MatrixThread.a=matrixA;
		MatrixThread.b=matrixB;
		
		*/
		
		
		/*This is for given a matrix and b matrix in the skeleton code*/
		int p=a.length;
        int noOfRowsForAThread=20;     //Initializing and declaring the number of rows for a thread
		
		Matrix.a=a;
		Matrix.b=b;
		Matrix.c = new int[a.length][b[0].length];
		
		int numberOfThreads =1;   //If the number of rows are less than the number of rows per thread the number of threads is 1
		
		/*If the number of rows are large we get the number of threads by dividing the number of rows by number of rows per thread*/
		
        if(p>=noOfRowsForAThread){
		numberOfThreads=p/noOfRowsForAThread;}
		
		/*Creating a array of thread.Threads are using as an array*/
		Matrix [] m =new Matrix [numberOfThreads];
		
		/*Getting the starting time before starting thread*/
		long tm = System.nanoTime();
		
		
		/*Starting of the array of thread.In this loop all threads are starting*/
		/*Creating more than one number of threads we can parallelize the operation*/
		/*By diving the number of rows of matrix A we can allocate some number of rows for each thread */
		
		for(int s=0;s<numberOfThreads;s++){
			m[s]= new Matrix((p/numberOfThreads)*s,(p/numberOfThreads)*(s+1));
			m[s].start();
		}
		
		
		/*Joining the thread by this loop. By join() method we can synchronize the process.It causes the currently running threads to stop executing until the thread it joins with completes its task. */
		
		for(int k=0;k<numberOfThreads;k++){
			m[k].join();
		}
	 
	tm = System.nanoTime()-tm; //Getting hte time for multiply two matrices
    System.out.println(tm);    //Printing the time 
	print_matrix(Matrix.c); //Printing the result matrix
	   
	 }
}


/*If we put the all rows into columns (if there is a matrix size of axb,we store that like a matrix size of 1x(a+b))we can use the memory efficiently and cache friendly.*/