public class Matrix extends Thread { 

    public static int [][] a; 
    public static int [][] b; 
    public static int [][] c; 
	   int row_new1;
	   int row_new2;

	
	
	 public Matrix(int row_new1,int row_new2) { // need to change this, might need some information 
   
		/*New bound of rows for one thread*/
		this.row_new1=row_new1;
		this.row_new2=row_new2;}
		
		
		/*For each thread the run method execute*/
		public void run(){
		
		int x=a.length;
		int y=b[0].length;
		int z=a[0].length;
	    int s,k;
		
		for(int i=row_new1; i<row_new2; i++)  //Multiplying the two matrices
	    for(int j=0; j<y; j++) {
		for( s=0, k=0; k<z; k++){ 
		    s += a[i][k] * b[k][j];}
			
		c[i][j] = s;
		
	    }

	 
		
	}	
}
	
	