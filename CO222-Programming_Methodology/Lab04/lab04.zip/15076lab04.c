#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define RESET		0
#define BRIGHT 		1

#define BLACK 		0
#define RED		1
#define GREEN		2
#define YELLOW		3
#define BLUE		4
#define MAGENTA		5
#define CYAN		6
#define	WHITE		7

void textcolor(int attr, int fg, int bg);

void textcolor(int attr, int fg, int bg)
{	char command[13];

	/* Command is the control command to the terminal */

	/* textcolor(BRIGHT,BLACK,WHITE) will have characters printed in
	black in white background */
	sprintf(command, "%c[%d;%d;%dm", 0x1B, attr, fg + 30, bg + 40);
	printf("%s", command);
}





int main(int argc, char **argv){
double d1;//declare the outer diameter
double d2;//declare the inner diameter
int a;//declare the variable of backgroundcolor
int b;//declare the variable of foreground color
int p=strcmp(argv[1],"donut");//compare the input figure with "donut" & "checker"
int q=strcmp(argv[1],"checker");

 if(argc<4){
printf("Not enough arguments\n");}//check the number of arguments are enough or not
else if(argc>4){
printf("Too many arguments\n");}
else if(p!=0 && q!=0){
printf("Requested figure is not available\n");}//check the input figure is available or not

else{

int bg0=strcmp(argv[2],"black");// compare the input  backgroundcolors with given colors
int bg1=strcmp(argv[2],"red");
int bg2=strcmp(argv[2],"green");
int bg3=strcmp(argv[2],"yellow");
int bg4=strcmp(argv[2],"blue");
int bg5=strcmp(argv[2],"magenta");
int bg6=strcmp(argv[2],"cyan");
int bg7=strcmp(argv[2],"white");

int fg0=strcmp(argv[3],"black");//compare the input foregrount colors with given colors
int fg1=strcmp(argv[3],"red");
int fg2=strcmp(argv[3],"green");
int fg3=strcmp(argv[3],"yellow");
int fg4=strcmp(argv[3],"blue");
int fg5=strcmp(argv[3],"magenta");
int fg6=strcmp(argv[3],"cyan");
int fg7=strcmp(argv[3],"white");


//give the numbers for colors
if(bg0==0){
a=0;}
else if(bg1==0){
a=1;}
else if(bg2==0){
a=2;}
else if(bg3==0){
a=3;}
else if(bg4==0){
a=4;}
else if(bg5==0){
a=5;}
else if(bg6==0){
a=6;}
else if(bg7==0){
a=7;}
else{
a=8;}

  
if(fg0==0){
b=0;}
else if(fg1==0){
b=1;}
else if(fg2==0){
b=2;}
else if(fg3==0){
b=3;}
else if(fg4==0){
b=4;}
else if(fg5==0){
b=5;}
else if(fg6==0){
b=6;}
else if(fg7==0){
b=7;}
else{
b=8;}


if(a==8){
printf("Background color is not available\n");}//check the input background and foreground colors are available or not
else if(b==8){
printf("Foreground color is not available\n");}
else{
//print the checker
   if(q==0){

      char arr[8][8];


      for(int i=0;i<8;i++){

         if(i%2==0){
          for(int t=0;t<8;t++){

           for(int j=0;j<8;j++){

             if(j%2==0){

              textcolor(BRIGHT,a,b);
              printf("        ");}
             else{
              textcolor(BRIGHT,b,a);
              printf("        ");}}
              textcolor(RESET,b,a);
            printf("\n");}}

          else{
           for(int s=0;s<8;s++){
             for (int k=0;k<8;k++){
               if(k%2==0){
                 textcolor(BRIGHT,b ,a);
                 printf("        ");}
               else{
                 textcolor(BRIGHT,a,b);
                 printf("        ");}}
                 textcolor(RESET,b,a);
               printf("\n");}}}
}

    else{
//print the donut
       scanf("%lf",&d1);
       d2=d1/2;
       double i,j;
       for(i=-d1/2;i<d1/2;i++)
        {
         for(j=-d1/2;j<d1/2;j++)
        {
            if((i*i+j*j<(d1/2)*(d1/2)) && (i*i+j*j>(d2/2)*(d2/2)))
               {textcolor(BRIGHT,a,b);
                printf(" ");}
            else{

               textcolor(BRIGHT,b,a);
                printf(" ");}
         textcolor(RESET,b,a);

        }
        printf("\n");}
}

}}

	textcolor(RESET, WHITE, BLACK);	
	return 0;
	
	
}
