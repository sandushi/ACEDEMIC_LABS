#include<stdio.h>
#include<string.h>


int main(){
char p1[2];
char p2[2];
scanf("%s",p1);
scanf("%s",p2);
if((strcmp(p1,"L")==0||strcmp(p1,"R")==0||strcmp(p1,"C")==0||strcmp(p1,"S")==0||strcmp(p1,"P")==0)&&(strcmp(p2,"L")==0||strcmp(p2,"R")==0||strcmp(p2,"C")==0||strcmp(p2,"S")==0||strcmp(p2,"P")==0)){
   if(strcmp(p1,p2)==0){
     printf("tie\n");}

   else if (strcmp(p1,"R")==0){
          if(strcmp(p2,"C")==0||strcmp(p2,"L")==0){
              printf("p1 wins\n");}
          else{
              printf("p2 wins\n");}}

   else if(strcmp(p1,"C")==0){
          if(strcmp(p2,"L")==0||strcmp(p2,"P")==0){
              printf("p1 wins\n");}
          else{
              printf("p2 wins\n");}}
   else if(strcmp(p1,"L")==0){
          if(strcmp(p2,"P")==0||strcmp(p2,"S")==0){
               printf("p1 wins\n");}
          else{
               printf("p2 wins\n");}}
   else if(strcmp(p1,"P")==0){
          if(strcmp(p2,"R")==0||strcmp(p2,"S")==0){
               printf("p1 wins\n");}
          else{
               printf("p2 wins\n");}}
   else {
          if(strcmp(p2,"R")==0||strcmp(p2,"C")==0){
               printf("p1 wins\n");}
          else{
               printf("p2 wins\n");}}}
else{
  printf("wrong input\n");}
return 0;}


