#include<stdio.h>

int main(){
int w;//number of columns
int h;//number of rows
int b;//blue values
int g; //red values
int r;//green values
int p;

scanf("%d %d",&w,&h);//get the values from reader
printf("%d %d\n",w,h);//print the number of columns & rows
int x=w;
int y=h;
int pd;//padding values
if((x*3)%4==0){
pd=0;}
else{

pd=4-((3*x)%4);}//findinding the number of padding values
for(int c=1;c<=y;c++){
for(int i=1;i<=x;i++){
scanf("%d %d %d\n",&b,&g,&r);
int G=255-g;//modify the values
int B=255-b;
int R=255-r;
printf("%d %d %d\n",B,G,R);}
for(int j=1;j<=pd;j++){
scanf("%d\n",&p);
printf("%d\n",p);}}
return 0;}


