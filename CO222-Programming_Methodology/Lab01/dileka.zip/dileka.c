#include<stdio.h>
#include<math.h>


int main(){
int u;
float units;
float billcost;
printf("enter the number of units: \n");
scanf("%f",&units);

  if(units>0){int u=ceil(units);
   if(u==units){
     if (units<=60){
        if(units<=30)
        billcost=(2.50*units+30);
        else
        billcost=2.50*30+(units-30)*4.85+60.00;}
     else{
       if(units<=90){
           billcost=60*7.85+(units-60)*10.00+90.00;}
       else if(units<=120){
           billcost=60*7.85+30*10.00+(units-90)*27.75+480.00;}
       else if(units<=180){
           billcost=60*7.85+30*10.00+30*27.75+(units-120)*32.00+480.00;}
       else
           {billcost=60*7.85+30*10.00+30*27.75+60*32.00+(units-180)*45.00+540.00;}}

     printf("the billcost is:%0.2f\n",billcost) ;}
    else
     printf("-1\n");}



  else
  {printf("-1\n");}

return 0;}
