// Week8_GCD.c
// Compute the greatest common divisor (GCD) of two
// non-negative integers, not both zero.
#include <stdio.h>
#include<stdlib.h>

int gcd(int, int);

int main(void) {
        int num1, num2;

        printf("Enter two integers: ");
        scanf("%d %d", &num1, &num2);

        printf("gcd(%d, %d) = %d\n", num1, num2, gcd(num1, num2));
        return 0;
}

// Compute the greatest common divisor of a and b
// Precond: a and b non-negative, not both zero
int gcd(int a, int b) {
        // to be completed
        if(a<0 || b<0 || a==0){       //check whether the input numbers are non_negative or a==0
		exit(1);}
	else{	
             if(b!=0){                 
                return gcd(b,(a%b));}  //Get the gcd wheb b!=0
                return a;}}
     



}

