// Week10_SumDigits.c
// Sum up all digits in an integer.

#include <stdio.h>
#include<stdlib.h>

int sum_digits(int);

int sumArray(int [], int);

int main(void) {
        int num;

        printf("Enter a non-negative integer: ");
        scanf("%d", &num);

        printf("Sum of its digits = %d\n", sum_digits(num));

        return 0;
}

// Return sum of digits in integer n
// Pre-cond: n >= 0
int sum_digits(int n) {
        if(n==0){
                return 0;} // If the number is zero the sum of digits=0
        else if(n<0){
                exit(1);}  //If negative number is enter,exit from the program
        else if(n<10){
                return n;}  //If the number is less than 10, the sum of digits is equal to the number

        return (n%10) + sum_digits(n/10);
       

}
     
