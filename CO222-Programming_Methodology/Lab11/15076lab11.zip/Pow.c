// Week10_Pow.c
// Compute the nth power of x, where
// n is a non-negative integer.
#include <stdio.h>
#include<stdlib.h>

double mypow(double, int);

int main(void) {
        double x;
        int n;

        printf("Enter x and n: ");
        scanf("%lf %d", &x, &n);

        printf("mypow(%f, %d) = %f\n", x, n, mypow(x, n));
        return 0;
}

// Compute the nth power of x.
// Precond: n >= 0


double mypow(double x, int n) {
        // to be completed

        if(n<0){
                exit(1);}      //Check whether input number is negative

        else if(n==0){
                return 1;}      //If n==0 the output is 1

        else if(n==1){          //If n==1 the output is the entered number
                return x;}

        return x* mypow(x,n-1);

}

